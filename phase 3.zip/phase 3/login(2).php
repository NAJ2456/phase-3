<?php
// Database configuration
$servername = "localhost"; // Change if your database is hosted elsewhere
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "brave"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare and bind
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);

    // Execute the statement
    $stmt->execute();
    
    // Store the result
    $result = $stmt->get_result();

    // Check if a user exists
    if ($result->num_rows > 0) {
        // User found, proceed to login
        // Start session
        session_start();
        $_SESSION['username'] = $username; // Store username in session

        // Redirect to dashboard
        header("Location: dashboard.php"); // Change to your dashboard page
        exit(); // Make sure to call exit after redirecting
    } else {
        // User not found
        echo "<script>alert('Invalid username or password.'); window.location.href='index.php';</script>";
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();