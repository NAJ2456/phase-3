
<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.php"); // Redirect to login page if not logged in
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vigilant City Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            margin: 20px 0;
        }
        .video-feed {
            height: 400px;
            background-color: black;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Vigilant City</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link" href="#">Dashboard</a>
                <li class="nav-item">
                    <a class="nav-link" href="login.html">login</a>
                </li>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="alert.html">Alerts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="analytics.html">Analytics</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="usermanagement.html">User  Management</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.html">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container">
    <h1 class="mt-4">Dashboard</h1>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Live Video Feed
                </div>
                <div class="card-body video-feed">
                    <h5>Live Video Feed Display</h5>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    Alerts
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        <li class="list-group-item list-group-item-danger">Alert: Suspicious Activity Detected</li>
                        <li class="list-group-item list-group-item-warning">Alert: Traffic Violation Detected</li>
                        <li class="list-group-item list-group-item-success">Alert: Emergency Services Responding</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Recent Analytics
                </div>
                <div class="card-body">
                    <p>Crime Rate: Decreased by 15% in the last month</p>
                    <p>Public Safety Index: Improved by 10% in the last quarter</p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    User Management
                </div>
                <div class="card-body">
                    <button class="href-usemanagement.html btn-primary">Add User</button>
                    <button class="btn btn-secondary">View Users</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>Z
</html>